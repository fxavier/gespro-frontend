/**
 * E2E — issue #77: «IVA 0% é gravado como 16%».
 *
 * O formulário fazia `Number(l.taxaIva) || 0.16`: o 0 é falsy, e uma linha
 * escolhida a «0%» era mostrada e/ou gravada a 16%. Estes testes conduzem só a
 * UI (admin do seed) e comparam o que o ecrã mostra antes de gravar com o que o
 * documento gravado mostra depois.
 *
 * Cria documentos por corrida — corre contra a base ISOLADA (gespro_e2e77),
 * nunca contra `gespro`: facturas isentas partiriam a golden fixture da spec 22.
 *
 * As opções do Select de IVA escolhem-se pelo início do rótulo (/^0%/, /^16%/):
 * cobre os rótulos decididos (ROTULOS_TAXA_IVA: «0% (isento)», «16%») e os de
 * /vendas/faturas/nova («0% (isento)», «16% (padrão)»), e também os de hoje
 * («0%», «16%») — assim o vermelho de hoje é o defeito, não um rótulo em falta.
 */

import { test, expect, type Page, type Locator, type Route } from '@playwright/test';

/** aaaa-mm-dd no dia civil de Maputo, com deslocamento em dias. */
function diaMaputo(deslocamentoDias = 0): string {
  const d = new Date(Date.now() + deslocamentoDias * 86_400_000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Maputo' }).format(d);
}

/** «1 000,00 MTn» / «MT 1000,00» → 1000 */
function paraNumero(texto: string | null): number {
  const limpo = (texto ?? '').replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.');
  return Number(limpo);
}

/** O valor imediatamente a seguir a um rótulo (ignora cabeçalhos de tabela). */
function valorAoLado(page: Page, rotulo: string): Locator {
  return page.locator(
    `xpath=//*[not(self::th)][normalize-space(text())="${rotulo}"]/following-sibling::*[1]`,
  );
}

async function esperarValor(loc: Locator, esperado: number, descricao: string) {
  await expect
    .poll(async () => paraNumero(await loc.textContent()), { message: descricao, timeout: 15_000 })
    .toBe(esperado);
}

/**
 * Carrega na acção de submeter e devolve o corpo da resposta da Server Action
 * que gravou o documento. O pedido identifica-se pelo payload (a descrição leva
 * a marca «E2E #77»). O corpo lê-se INTERCEPTANDO o pedido (`route.fetch`), não
 * com `response.text()`: o formulário navega logo a seguir e o Chromium deita
 * fora o corpo («No data found for resource»).
 */
async function submeterECapturar(page: Page, botao: Locator): Promise<{ id: string | null; numero: string | null; corpo: string }> {
  let entregar!: (corpo: string) => void;
  const corpoLido = new Promise<string>((r) => (entregar = r));
  const handler = async (route: Route) => {
    const req = route.request();
    if (req.method() === 'POST' && req.headers()['next-action'] && (req.postData() ?? '').includes('E2E #77')) {
      const resposta = await route.fetch();
      const corpo = await resposta.text();
      await route.fulfill({ response: resposta, body: corpo });
      entregar(corpo);
    } else {
      await route.fallback();
    }
  };
  await page.route('**/*', handler);
  try {
    await botao.click();
    const corpo = await Promise.race([
      corpoLido,
      new Promise<string>((_, rej) => setTimeout(() => rej(new Error('a gravação não foi pedida ao servidor em 60s')), 60_000)),
    ]);
    const id = /"ok":true,"data":\{"id":"([^"]+)"/.exec(corpo)?.[1] ?? null;
    const numero = /"numero":"([^"]+)"/.exec(corpo)?.[1] ?? null;
    return { id, numero, corpo };
  } finally {
    await page.unroute('**/*', handler);
  }
}

async function escolherCliente(page: Page) {
  await page.getByRole('combobox', { name: /Cliente/ }).click();
  await page.getByPlaceholder(/Pesquisar por código/).fill('Maria');
  const opcao = page.getByRole('option', { name: /Maria/ }).first();
  await expect(opcao).toBeVisible({ timeout: 15_000 });
  await opcao.click();
  await expect(page.getByRole('combobox', { name: /Cliente/ })).toHaveText(/Maria/);
}

async function escolherTaxa(page: Page, seletor: Locator, rotulo: RegExp) {
  await seletor.click();
  await page.getByRole('option', { name: rotulo }).click();
  await expect(seletor).toHaveText(rotulo);
}

/**
 * #329: uma linha a 0% numa factura exige «Motivo de isenção» (ADR-0039 §4) — o campo
 * aparece quando a taxa é 0%. Preenche-se para que estes testes continuem a provar o #77.
 */
async function preencherMotivoIsencao(page: Page) {
  const campo = page.getByLabel(/^Motivo de isenção/).first();
  await expect(campo).toBeVisible({ timeout: 15_000 });
  await campo.fill('Isento nos termos do Código do IVA');
}

/**
 * Preenche um `<input type="date">` com `aaaa-mm-dd` pelo `fill`, que fixa o
 * valor e dispara `input`/`change` de uma vez. Escrever `ddmmaaaa` tecla a tecla
 * dependia do locale e da ordem dos segmentos do browser: no Chromium/Linux da
 * CI o cursor não saltava do mês e o ano ficava `92026` (#237). Confirma-se o
 * valor que o campo ficou a ter antes de seguir.
 */
async function preencherData(campo: Locator, iso: string) {
  await campo.fill(iso);
  await expect(campo).toHaveValue(iso);
}

async function abrirNovaFatura(page: Page) {
  await page.goto('/faturacao/nova');
  await expect(page.getByRole('heading', { name: 'Nova Fatura' })).toBeVisible({ timeout: 30_000 });
  await page.waitForLoadState('networkidle');
}

const ivaLinha = (page: Page, i: number) => page.getByRole('combobox', { name: /IVA/i }).nth(i);

test.describe('/faturacao/nova — linha isenta', () => {
  test('uma linha nova começa em 16% VISÍVEL no Select', async ({ page }) => {
    await abrirNovaFatura(page);
    await expect(ivaLinha(page, 0)).toHaveText(/^16%/);
  });

  test('uma linha a 0% × 1000: total 1000,00 antes de emitir; o documento emitido tem IVA 0,00 e total 1000,00', async ({ page }) => {
    test.setTimeout(120_000);
    await abrirNovaFatura(page);

    await escolherCliente(page);
    await page.getByLabel('Data de Vencimento').fill(diaMaputo(30));
    await page.getByLabel('Descrição da linha 1').fill('Livro escolar (isento) — E2E #77');
    await page.getByLabel('Preço unitário linha 1').fill('1000');
    await escolherTaxa(page, ivaLinha(page, 0), /^0%/);
    await preencherMotivoIsencao(page);

    // O que o ecrã mostra ANTES de gravar.
    await esperarValor(valorAoLado(page, 'IVA').last(), 0, 'IVA mostrado antes de emitir');
    await esperarValor(valorAoLado(page, 'Total').last(), 1000, 'Total mostrado antes de emitir');

    const { id, corpo } = await submeterECapturar(page, page.getByRole('button', { name: 'Emitir Fatura' }));
    expect(id, `a emissão não devolveu o documento: ${corpo.slice(0, 400)}`).not.toBeNull();

    // O que ficou GRAVADO.
    await page.goto(`/faturacao/${id}`);
    await esperarValor(valorAoLado(page, 'IVA').first(), 0, 'IVA do documento emitido');
    await esperarValor(valorAoLado(page, 'Total').first(), 1000, 'Total do documento emitido');
  });

  test('uma linha a 0% e outra a 16% (1000 cada): IVA 160,00 e total 2160,00, antes e depois', async ({ page }) => {
    test.setTimeout(120_000);
    await abrirNovaFatura(page);

    await escolherCliente(page);
    await page.getByLabel('Data de Vencimento').fill(diaMaputo(30));
    await page.getByLabel('Descrição da linha 1').fill('Isento — E2E #77');
    await page.getByLabel('Preço unitário linha 1').fill('1000');
    await escolherTaxa(page, ivaLinha(page, 0), /^0%/);
    await preencherMotivoIsencao(page);

    await page.getByRole('button', { name: 'Adicionar linha' }).click();
    await page.getByLabel('Descrição da linha 2').fill('Normal — E2E #77');
    await page.getByLabel('Preço unitário linha 2').fill('1000');
    await escolherTaxa(page, ivaLinha(page, 1), /^16%/);

    await esperarValor(valorAoLado(page, 'IVA').last(), 160, 'IVA mostrado antes de emitir');
    await esperarValor(valorAoLado(page, 'Total').last(), 2160, 'Total mostrado antes de emitir');

    const { id, corpo } = await submeterECapturar(page, page.getByRole('button', { name: 'Emitir Fatura' }));
    expect(id, `a emissão não devolveu o documento: ${corpo.slice(0, 400)}`).not.toBeNull();

    await page.goto(`/faturacao/${id}`);
    await esperarValor(valorAoLado(page, 'IVA').first(), 160, 'IVA do documento emitido');
    await esperarValor(valorAoLado(page, 'Total').first(), 2160, 'Total do documento emitido');
  });
});

test.describe('/compras/pedidos/novo — item isento', () => {
  /**
   * Não há página de detalhe do pedido (`/compras/pedidos/[id]` não existe):
   * o valor gravado lê-se na coluna «Valor Total» da listagem, na linha do
   * número devolvido pela gravação.
   */
  test('item a 0% × 1000: o pedido gravado tem valor total 1000,00 (sem IVA)', async ({ page }) => {
    test.setTimeout(120_000);

    await page.goto('/compras/pedidos/novo');
    await expect(page.getByRole('heading', { name: 'Novo Pedido de Compra' })).toBeVisible({ timeout: 30_000 });
    await page.waitForLoadState('networkidle');

    // #265: o fornecedor escolhe-se na combobox (já não se cola o id). Escolhe-se o primeiro
    // fornecedor da lista inicial — o mesmo que antes se tirava da listagem de fornecedores.
    const caixaFornecedor = page.getByRole('combobox', { name: /Fornecedor/i }).first();
    await caixaFornecedor.click();
    const popFornecedor = page.locator('[data-radix-popper-content-wrapper]').last();
    const primeiroFornecedor = popFornecedor.getByRole('option').first();
    await expect(primeiroFornecedor, 'a combobox de fornecedor abriu sem opções').toBeVisible({ timeout: 15_000 });
    const nomeFornecedor = (await primeiroFornecedor.innerText()).split('\n')[0].trim();
    await primeiroFornecedor.click();
    await expect(caixaFornecedor).toContainText(nomeFornecedor);
    await page.getByLabel('Condições de Pagamento').fill('30 dias');
    await page.getByLabel('Data de Entrega Prevista').fill(diaMaputo(30));
    await page.getByLabel('Endereço de Entrega').fill('Av. 25 de Setembro, Maputo');
    await page.getByLabel('Descrição do item 1').fill('Livros escolares (isento) — E2E #77');
    await page.getByLabel('Preço unitário item 1').fill('1000');
    await escolherTaxa(page, page.getByRole('combobox', { name: /IVA/i }).first(), /^0%/);

    await esperarValor(valorAoLado(page, 'IVA').last(), 0, 'IVA mostrado antes de criar');
    await esperarValor(valorAoLado(page, 'Total').last(), 1000, 'Total mostrado antes de criar');

    const { numero, corpo } = await submeterECapturar(page, page.getByRole('button', { name: 'Criar Pedido' }));
    expect(numero, `a criação não devolveu o pedido: ${corpo.slice(0, 400)}`).not.toBeNull();

    await page.waitForURL(/\/compras\/pedidos$/, { timeout: 60_000 });
    const linha = page.locator('tbody tr', { hasText: numero! });
    await expect(linha).toBeVisible({ timeout: 15_000 });
    await esperarValor(linha.locator('td').nth(4), 1000, `Valor Total gravado do pedido ${numero}`);
  });
});

test.describe('/vendas/faturas/nova — linha isenta', () => {
  test('linha a 0% × 1000: o documento emitido tem IVA 0,00 e total 1000,00', async ({ page }) => {
    test.setTimeout(120_000);
    await page.goto('/vendas/faturas/nova');
    await expect(page.getByRole('heading', { name: 'Nova Fatura' })).toBeVisible({ timeout: 30_000 });
    await page.waitForLoadState('networkidle');

    // #93: a série já não se escolhe — é a activa do tipo no ano da data de emissão.
    await escolherCliente(page);
    await preencherData(page.getByLabel(/Data de emissão/), diaMaputo(0));
    await preencherData(page.getByLabel(/Data de vencimento/), diaMaputo(30));
    await page.getByLabel(/Descrição/).first().fill('Livro escolar (isento) — E2E #77 vendas');
    await page.getByLabel(/Preço Unit/).first().fill('1000');
    await escolherTaxa(page, page.getByRole('combobox', { name: /^IVA/ }).first(), /^0%/);
    await preencherMotivoIsencao(page);

    const { id, corpo } = await submeterECapturar(page, page.getByRole('button', { name: 'Emitir Fatura' }));
    expect(id, `a emissão não devolveu o documento: ${corpo.slice(0, 400)}`).not.toBeNull();

    await page.goto(`/vendas/faturas/${id}`);
    await esperarValor(valorAoLado(page, 'IVA').first(), 0, 'IVA do documento emitido');
    await esperarValor(valorAoLado(page, 'Total').first(), 1000, 'Total do documento emitido');
  });
  /**
   * #242: as datas por omissão vinham de `toISOString()` (dia UTC) num módulo
   * cliente e nem entravam no estado do formulário. Sem tocar nos campos, o
   * documento emitido tem de sair com a data de hoje em Maputo — a que decide
   * a série e o período.
   */
  test('sem tocar nas datas: o documento sai com a data de hoje em Maputo', async ({ page }) => {
    test.setTimeout(120_000);
    await page.goto('/vendas/faturas/nova');
    await expect(page.getByRole('heading', { name: 'Nova Fatura' })).toBeVisible({ timeout: 30_000 });
    await page.waitForLoadState('networkidle');

    await expect(page.getByLabel(/Data de emissão/)).toHaveValue(diaMaputo(0));
    await escolherCliente(page);
    await page.getByLabel(/Descrição/).first().fill('Livro escolar (isento) — E2E #77 vendas, datas por omissão');
    await page.getByLabel(/Preço Unit/).first().fill('1000');
    await escolherTaxa(page, page.getByRole('combobox', { name: /^IVA/ }).first(), /^0%/);
    await preencherMotivoIsencao(page);

    const { id, corpo } = await submeterECapturar(page, page.getByRole('button', { name: 'Emitir Fatura' }));
    expect(id, `a emissão não devolveu o documento: ${corpo.slice(0, 400)}`).not.toBeNull();

    const [ano, mes, dia] = diaMaputo(0).split('-');
    await page.goto(`/vendas/faturas/${id}`);
    await expect(valorAoLado(page, 'Data de emissão').first()).toHaveText(`${dia}/${mes}/${ano}`, {
      timeout: 15_000,
    });
  });
});
