/**
 * Configurações de Contabilidade — Server Component shell.
 *
 * Dois defeitos corrigidos face à versão anterior:
 * 1. Verificação de permissão `financas:configurar` (não só de sessão).
 * 2. Formulário ligado às actions reais — o estado inicial é carregado aqui
 *    e passado ao Client Component como `initialData`.
 */

import Link from 'next/link';
import { redirect } from 'next/navigation';
import { auth } from '@/lib/auth';
import { runWithTenantContext } from '@/server/db/tenant-extension';
import * as contabilidadeService from '@/server/services/financas/contabilidade.service';
import { PageHeader } from '@/components/patterns';
import { CalendarioForm } from './_components/calendario-form';

export default async function ConfiguracoesContabilidadePage() {
  const session = await auth();
  if (!session?.user) redirect('/auth/login');

  const { tenantId, id: userId, permissions } = session.user;

  if (!permissions.includes('financas:configurar')) {
    return (
      <div className="p-6 space-y-6">
        <PageHeader
          title="Configurações de Contabilidade"
          description="Regime contabilístico, exercício fiscal e contas padrão"
          breadcrumbs={[
            { label: 'Contabilidade', href: '/contabilidade' },
            { label: 'Configurações' },
          ]}
        />
        <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-6 text-sm">
          <p className="font-medium text-destructive">Acesso não autorizado</p>
          <p className="mt-1 text-muted-foreground">
            Não tem permissão para aceder às configurações de contabilidade. Contacte o
            administrador do sistema.
          </p>
        </div>
      </div>
    );
  }

  const ctx = { tenantId, userId };
  const calendario = await runWithTenantContext(ctx, () =>
    contabilidadeService.obterCalendarioContabilistico(ctx)
  );

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="Configurações de Contabilidade"
        description="Calendário de abertura de exercícios e fecho automático de períodos"
        breadcrumbs={[
          { label: 'Contabilidade', href: '/contabilidade' },
          { label: 'Configurações' },
        ]}
      />
      <CalendarioForm initialData={calendario} />
      <div className="rounded-lg border p-4 text-sm">
        <p className="font-medium">Meios de pagamento do POS</p>
        <p className="mt-1 text-muted-foreground">
          Conta bancária que cada venda POS debita por cartão, transferência, M-Pesa ou e-Mola.{' '}
          <Link
            href="/contabilidade/configuracoes/meios-pagamento-pos"
            className="text-primary underline-offset-4 hover:underline"
          >
            Configurar contas dos meios de pagamento
          </Link>
        </p>
      </div>
      <div className="rounded-lg border p-4 text-sm">
        <p className="font-medium">Naturezas de nota de débito</p>
        <p className="mt-1 text-muted-foreground">
          Conta que cada nota de débito credita, por natureza (acerto de preço, juros de mora, despesas
          repercutidas, penalização, outro).{' '}
          <Link
            href="/contabilidade/configuracoes/naturezas-nota-debito"
            className="text-primary underline-offset-4 hover:underline"
          >
            Configurar contas por natureza de nota de débito
          </Link>
        </p>
      </div>
    </div>
  );
}
